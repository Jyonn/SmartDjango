from SmartDjango import Excp

HttpPackMiddleware = Excp.handle
